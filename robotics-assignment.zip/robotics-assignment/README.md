# Robotics Assignment: Localization, Mapping & Planning

This project implements three fundamental algorithms for mobile robotics:
1. Monte Carlo Localization (MCL)
2. Grid-based SLAM (Simultaneous Localization and Mapping)
3. D* Path Planning

Additionally, we implement a Deep Learning enhancement for the Monte Carlo Localization algorithm to improve sensor measurement accuracy.

## Project Structure

```
robotics-assignment/
├── src/                         # Python implementation
│   ├── localization/            # Localization algorithms
│   │   └── monte_carlo_localization.py
│   ├── mapping/                 # Mapping algorithms
│   │   └── grid_slam.py
│   ├── planning/                # Path planning algorithms
│   │   └── dstar_planner.py
│   ├── deep_learning/           # Deep learning enhancements
│   │   └── deep_mcl.py
│   ├── utils/                   # Utility functions
│   │   └── robot_utils.py
│   └── integrated_robot.py      # Integration of all components
│
└── ros2_ws/                     # ROS2 implementation
    └── src/
        └── mcl_localization/    # MCL implementation for ROS2
```

## Requirements

- Python 3.8+
- NumPy
- Matplotlib
- PyTorch (for deep learning enhancement)
- ROS2 Jazzy (for ROS2 implementation)

## Running the Python Implementation

You can run the integrated simulation using:

```bash
cd robotics-assignment
python src/integrated_robot.py
```

This will run a simulation that combines all three algorithms:
1. The robot uses Monte Carlo Localization to track its position
2. It builds a map of the environment using Grid-based SLAM
3. It plans paths using the D* algorithm

The simulation results will be saved in the `visualization` directory.

## Running the ROS2 Implementation

### Setup

1. Install ROS2 Jazzy on Ubuntu 22.04 following the [official installation guide](https://docs.ros.org/en/jazzy/Installation.html).

2. Create a workspace and clone this repository:
```bash
mkdir -p ~/ros2_ws/src
cd ~/ros2_ws/src
git clone https://github.com/yourusername/robotics-assignment.git
```

3. Build the workspace:
```bash
cd ~/ros2_ws
colcon build --packages-select mcl_localization
source install/setup.bash
```

### Running Monte Carlo Localization with ROS2

1. Launch the MCL node with the provided launch file:
```bash
ros2 launch mcl_localization mcl.launch.py
```

2. You can use RViz2 to visualize the localization:
```bash
ros2 run rviz2 rviz2
```

3. In RViz, add displays for:
   - Map (topic: `/map`)
   - PoseArray (topic: `/particlecloud`)
   - MarkerArray (topic: `/particle_markers`)
   - TF

4. To test localization with a real or simulated robot, ensure it publishes:
   - Laser scan data on the `/scan` topic
   - Odometry data on the `/odom` topic

5. Set an initial pose by using the "2D Pose Estimate" tool in RViz.

### Creating a Custom Map

1. Generate a map using a SLAM algorithm like gmapping:
```bash
ros2 run nav2_map_server map_saver_cli -f ~/ros2_ws/src/robotics-assignment/ros2_ws/src/mcl_localization/maps/mymap
```

2. Update the launch file to use your custom map:
```bash
ros2 launch mcl_localization mcl.launch.py map_yaml_path:=/path/to/mymap.yaml
```

## Deep Learning Enhancement

We've enhanced the Monte Carlo Localization algorithm with a neural network that improves sensor measurement accuracy. The neural network acts as a filter that corrects noisy sensor readings before they're used in the particle filter.

### Why Deep Learning for MCL?

In real-world robotics applications, sensor measurements often contain noise, bias, and other imperfections. Traditional methods use predefined noise models, but these don't always capture the complex patterns of real sensor behavior.

Our deep learning approach:
1. Learns from examples of noisy and true measurements
2. Can handle non-linear, non-Gaussian noise patterns
3. Adapts to specific sensor characteristics
4. Improves localization accuracy by providing better measurement likelihood estimates

The implementation can be found in `src/deep_learning/deep_mcl.py`.

## Algorithms Overview

### Monte Carlo Localization (MCL)
- Represents the robot's belief about its position using a set of weighted particles
- Uses a motion model to predict particle movement
- Updates particle weights based on sensor measurements
- Resamples particles based on their weights

### Grid-based SLAM
- Builds a grid-based occupancy map of the environment
- Updates grid cells based on sensor measurements
- Simultaneously tracks the robot's position

### D* Path Planning
- Efficiently plans paths in dynamic environments
- Can quickly replan when new obstacles are discovered
- More efficient than A* for environments that change over time

## Evaluation

Our integrated system shows:
1. Accurate localization even with noisy sensors (thanks to the deep learning enhancement)
2. Effective mapping in unknown environments
3. Efficient path planning and replanning

## Future Work

- Implementing more advanced deep learning models for sensor fusion
- Adding reinforcement learning for adaptive navigation
- Extending the ROS2 implementation to include SLAM and planning

## References

1. Thrun, S., Burgard, W., & Fox, D. (2005). Probabilistic robotics. MIT press.
2. Koenig, S., & Likhachev, M. (2002, July). D* lite. In AAAI/IAAI (pp. 476-483).
3. Grisettiyz, G., Stachniss, C., & Burgard, W. (2005, April). Improving grid-based slam with rao-blackwellized particle filters by adaptive proposals and selective resampling. In Proceedings of the 2005 IEEE international conference on robotics and automation (pp. 2432-2437). IEEE.
