# Running the ROS2 Implementation on Ubuntu

This guide provides detailed instructions for setting up and running the ROS2 Monte Carlo Localization implementation on Ubuntu.

## Prerequisites

- Ubuntu 22.04 (Jammy Jellyfish)
- ROS2 Jazzy Jalisco

## Step 1: Install ROS2 Jazzy

Follow these commands to install ROS2 Jazzy on Ubuntu 22.04:

```bash
# Set locale
sudo apt update && sudo apt install locales
sudo locale-gen en_US en_US.UTF-8
sudo update-locale LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8
export LANG=en_US.UTF-8

# Add ROS2 repository
sudo apt install software-properties-common
sudo add-apt-repository universe
sudo apt update

# Add ROS2 GPG key
sudo apt install curl
sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key -o /usr/share/keyrings/ros-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros.org/ros2/ubuntu $(. /etc/os-release && echo $UBUNTU_CODENAME) main" | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null

# Install ROS2 packages
sudo apt update
sudo apt install ros-jazzy-desktop  # Full desktop installation

# Install dependencies for building packages
sudo apt install python3-colcon-common-extensions python3-rosdep python3-vcstool
sudo rosdep init
rosdep update
```

## Step 2: Create a ROS2 Workspace

```bash
# Create and navigate to the workspace directory
mkdir -p ~/ros2_ws/src
cd ~/ros2_ws/src

# Clone the repository (replace with your actual repository URL)
git clone https://github.com/yourusername/robotics-assignment.git

# Install dependencies
cd ~/ros2_ws
rosdep install --from-paths src --ignore-src -r -y

# Build the workspace
colcon build --packages-select mcl_localization

# Source the workspace
source install/setup.bash
```

## Step 3: Create a Map (Optional)

If you want to create your own map instead of using the provided one:

### Option 1: Using a simulated environment with SLAM

```bash
# Install necessary packages
sudo apt install ros-jazzy-nav2-bringup ros-jazzy-slam-toolbox

# Launch the simulation and SLAM
ros2 launch nav2_bringup tb3_simulation_launch.py slam:=True

# In another terminal, control the robot to map the environment
ros2 run teleop_twist_keyboard teleop_twist_keyboard

# Once mapping is complete, save the map
ros2 run nav2_map_server map_saver_cli -f ~/ros2_ws/src/robotics-assignment/ros2_ws/src/mcl_localization/maps/mymap
```

### Option 2: Using a real robot with SLAM

```bash
# Launch the robot driver and SLAM
ros2 launch slam_toolbox online_async_launch.py

# Control the robot to map the environment
ros2 run teleop_twist_keyboard teleop_twist_keyboard

# Once mapping is complete, save the map
ros2 run nav2_map_server map_saver_cli -f ~/ros2_ws/src/robotics-assignment/ros2_ws/src/mcl_localization/maps/mymap
```

## Step 4: Run the Monte Carlo Localization

```bash
# Source the workspace (if not already done)
source ~/ros2_ws/install/setup.bash

# Launch the MCL node with the default map
ros2 launch mcl_localization mcl.launch.py

# Or launch with your custom map
ros2 launch mcl_localization mcl.launch.py map_yaml_path:=~/ros2_ws/src/robotics-assignment/ros2_ws/src/mcl_localization/maps/mymap.yaml
```

## Step 5: Visualize in RViz2

```bash
# Launch RViz2
ros2 run rviz2 rviz2
```

Configure RViz2 with the following displays:

1. **Global Options**:
   - Fixed Frame: `map`

2. **Add Display > Map**:
   - Topic: `/map`

3. **Add Display > PoseArray**:
   - Topic: `/particlecloud`

4. **Add Display > MarkerArray**:
   - Topic: `/particle_markers`

5. **Add Display > TF**

6. **Add Display > LaserScan** (if you have a laser scan source):
   - Topic: `/scan`

## Step 6: Set Initial Pose

In RViz2:
1. Click on the "2D Pose Estimate" button in the toolbar
2. Click on the map at the estimated position of the robot
3. Drag to indicate the orientation

The particle filter should initialize around this position.

## Step 7: Move the Robot

If you're using a simulated robot:

```bash
# Open a new terminal
source ~/ros2_ws/install/setup.bash
ros2 run teleop_twist_keyboard teleop_twist_keyboard
```

If you're using a real robot, ensure it's publishing odometry on the `/odom` topic and laser scans on the `/scan` topic.

## Troubleshooting

### Issue: MCL node can't find the map
Solution: Make sure the map path is correct and the map file exists.

```bash
# Check if the map file exists
ls -la ~/ros2_ws/src/robotics-assignment/ros2_ws/src/mcl_localization/maps/

# Specify the full path to the map
ros2 launch mcl_localization mcl.launch.py map_yaml_path:=$(pwd)/src/robotics-assignment/ros2_ws/src/mcl_localization/maps/map.yaml
```

### Issue: TF Transform Exceptions
Solution: Ensure your robot is publishing the correct transforms.

```bash
# Check existing transforms
ros2 run tf2_ros tf2_echo map odom
ros2 run tf2_ros tf2_echo odom base_footprint

# View the transform tree
ros2 run tf2_tools view_frames.py
```

### Issue: No Laser Scan Data
Solution: Verify that your laser scan topic is correctly configured.

```bash
# Check available scan topics
ros2 topic list | grep scan

# Update the launch file parameter if needed
ros2 launch mcl_localization mcl.launch.py scan_topic:=/your_scan_topic
```

## Advanced Configuration

You can adjust the MCL parameters by modifying the launch file or passing parameters at launch time:

```bash
# Increase the number of particles for better accuracy
ros2 launch mcl_localization mcl.launch.py num_particles:=2000

# Adjust motion noise parameters
ros2 launch mcl_localization mcl.launch.py motion_noise:="[0.05, 0.05, 0.03]"

# Start with global localization
ros2 launch mcl_localization mcl.launch.py global_localization:=true
```

## Running with a Turtlebot3 (Example)

If you're using a Turtlebot3 robot:

```bash
# Set the robot model
export TURTLEBOT3_MODEL=waffle

# Launch the robot
ros2 launch turtlebot3_bringup robot.launch.py

# In a new terminal, launch the MCL node
ros2 launch mcl_localization mcl.launch.py
```

## Running in Simulation with Gazebo (Example)

```bash
# Install Gazebo and Turtlebot3 simulation packages
sudo apt install ros-jazzy-gazebo-ros-pkgs ros-jazzy-turtlebot3-simulations

# Set the robot model
export TURTLEBOT3_MODEL=waffle

# Launch the simulation
ros2 launch turtlebot3_gazebo turtlebot3_world.launch.py

# In a new terminal, launch the MCL node
ros2 launch mcl_localization mcl.launch.py
```

## Conclusion

This completes the setup and running of the Monte Carlo Localization algorithm on ROS2 Jazzy in Ubuntu 22.04. The system can be used with both real and simulated robots, and can be extended with custom maps and configurations.
